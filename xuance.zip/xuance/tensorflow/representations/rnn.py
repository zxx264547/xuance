class Basic_RNN():
    def __init__(self):
        pass